	<div class="filter-section">
		<div class="short-header">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<ul>
							<li><a href="#">Mughal</a></li>
							<li><a href="#">Mughal</a></li>
							<li><a href="#">Mughal</a></li>
							<li><a href="#">Mughal</a></li>
							<li><a href="#">Mughal</a></li>
							<li><a href="#">Mughal</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="row">
				<div class="col-gl-12">
					<div class="quick-search">
						<h1>Quick Search</h1>
						<form class="quick-search-form">
							<div class="row">
								<div class="col-lg-2">
									<label>I am looking for</label>
									<select name="looking-for" class="form-control">
										<option>-- Select Gender --</option>
										<option>Male</option>
										<option>Female</option>
									</select>
								</div>
								<div class="col-lg-2">
									<label>Age From</label>
									<input type="number" name="" class="form-control" placeholder="18">
								</div>
								<div class="col-lg-2">
									<label>Age To</label>
									<input type="number" name="" class="form-control" placeholder="50">
								</div>
								<div class="col-lg-2">
									<label>Religion</label>
									<select class="form-control">
										<option>-- Select Religion --</option>
										<option>Islam</option>
										<option>Christion</option>
									</select>
								</div>
								<div class="col-lg-2">
									<label>Mother Tongue</label>
									<select class="form-control">
										<option>-- Select Mother Tongue --</option>
										<option>Punjabi</option>
									</select>
								</div>
								<div class="col-lg-2">
									<label>Marital Status</label>
									<select class="form-control">
										<option>-- Select Marital Status --</option>
										<option value="1">Never Married</option>
										<option value="2">Married</option>
										<option value="3">Divorced </option>
										<option value="4">Separated </option>
										<option value="5">Widowed</option>
									</select>
								</div>
								<div class="col-lg-12 text-center">
									<label class="control-label"></label>
									<input type="submit" name="" class="btn" value="Quick Search">
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="proposal-gallery">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 single-proposal-gallery">
					<div class="proposal-img text-center">
						<img src="<?php echo base_url("assets/user/img/user.jpg"); ?>">
					</div>
					<div class="proposal-details">
						<div class="row">
							<div class="col-lg-12 candidate-name">
								<label>Name:</label>
								<span>Sufiyan Shahid</span>
							</div>
							<div class="col-lg-12 candidate-age">
								<label>Age:</label>
								<span>23</span>
							</div>
							<div class="col-lg-12 religion">
								<label>Religion:</label>
								<span>Islam</span>
							</div>
							<div class="col-lg-12 candidate-age">
								<label>Cast:</label>
								<span>Mughal</span>
							</div>
							<div class="col-lg-12 candidate-age">
								<label>City:</label>
								<span>Lahore</span>
							</div>
							<div class="col-lg-12 proposal-detail-btn">
								<a href="#" class="btn">Show Complete Details</a>
							</div>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>