<div class="login-and-register">
	<div class="container">
		<div class="col-lg-12 form-section">
			<h1>Register Account</h1>
			<form>
				<div class="row">
					<div class="col-lg-12">
						<label class="control-label">Profile Created by:</label>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-4">
						<label class="control-label">Full Name</label>
						<input type="text" name="" class="form-control">
					</div>
					<div class="col-lg-4">
						<label class="control-label">Full Name</label>
						<input type="text" name="" class="form-control">
					</div>
				</div>
				<div class="row">
					<div class="col-lg-12 text-center">
						<input type="submit" name="" class="btn login-btn" value="Register">
					</div>
				</div>
				<div class="row">
					<div class="col-lg-12 text-center">
						<p>If have Account. Go to <a href="<?php echo base_url('login'); ?>">Login</a></p>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>