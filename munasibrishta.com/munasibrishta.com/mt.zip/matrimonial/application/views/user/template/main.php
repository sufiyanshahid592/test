<?php 
	$this->load->view("user/template/header");
	echo $main_content;
	$this->load->view("user/template/footer");
?>