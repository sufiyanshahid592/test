<!DOCTYPE html>
<html>
<head>
	<title>Matrimonial</title>
	<meta name="robots" content="noindex" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("assets/bootstrap/css/bootstrap.css"); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("assets/user/css/style.css"); ?>">
</head>
<body>
	<div class="header">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 header-logo">
					<a href="<?php echo base_url(); ?>"><img src="<?php echo base_url("assets/user/img/logo.png"); ?>"></a>
				</div>
				<div class="col-lg-9 header-navbar">
					<ul class="nav navbar-nav pull-right">
						<li><a href="<?php echo base_url(); ?>">Home</a></li>
						<li><a href="<?php echo base_url("login"); ?>">Login</a></li>
						<li><a href="<?php echo base_url("register"); ?>">Register</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
