	<div class="footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-3">
					<label>About</label>
					<p>People add proposal with small payout.</p>
				</div>
				<div class="col-lg-3">
					<label>Our Services</label>
					<ul>
						<li><a href="#">About Us</a></li>
						<li><a href="#">Contact Us</a></li>
						<li><a href="#">Privacy Policy</a></li>
						<li><a href="#">Terms and Condition</a></li>
					</ul>
				</div>
				<div class="col-lg-3">
					<label>Contact</label>
					<ul>
						<li><a href="#">Brain Books Urdu Bazar Lahore</a></li>
						<li><a href="#">info@matrimonial.com</a></li>
						<li><a href="#">+92 301 406 5723</a></li>
						<li><a href="#"></a></li>
					</ul>
				</div>
				<div class="col-lg-3">
					<label>Payment Methods</label>
					<img src="<?php echo base_url("assets/user/img/payment-methods.png"); ?>">
				</div>
			</div>
		</div>
	</div>
	<div class="short-footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 text-center">Copyright © 2020 <a href="<?php echo base_url(); ?>">Matrimonial.com</a>. Designed by Sufiyan Shahid All rights reserved.</div>
			</div>
		</div>
	</div>
	<script type="text/javascript" src="<?php echo base_url("assets/user/js/jquery.js"); ?>"></script>
	<script type="text/javascript" src="<?php echo base_url("assets/user/js/jquery.validate.js"); ?>"></script>
</body>
</html>