<?php 
	$this->load->view("admin/template/header");
	echo $main_content;
	$this->load->view("admin/template/footer");
?>