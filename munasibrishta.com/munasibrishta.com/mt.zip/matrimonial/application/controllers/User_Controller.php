<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_Controller extends CI_Controller {

	public function login(){
		$data = array();
		$data['main_content'] = $this->load->view("user/login-and-register/login", $data, true);
		$this->load->view("user/template/main", $data);
	}
	public function register(){
		$data = array();
		$data['main_content'] = $this->load->view("user/login-and-register/register", $data, true);
		$this->load->view("user/template/main", $data);
	}
}
