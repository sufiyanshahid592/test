<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'Home_Controller';
$route['login'] = 'User_Controller/login';
$route['register'] = 'User_Controller/register';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
